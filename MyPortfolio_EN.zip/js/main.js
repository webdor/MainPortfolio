$(window).on('load', function(){

    //vide.js - video background
    $('#header').vide('./video/cover', {
        bgColor: '#606161'
    });

});

